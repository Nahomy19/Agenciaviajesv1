package com.aplication.agenciaviajesrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestAgenciaviajesApplicationTests {

	@Test
	void contextLoads() {
	}

}
