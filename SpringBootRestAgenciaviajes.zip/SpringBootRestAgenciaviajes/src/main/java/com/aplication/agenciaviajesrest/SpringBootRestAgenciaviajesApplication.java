package com.aplication.agenciaviajesrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestAgenciaviajesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestAgenciaviajesApplication.class, args);
	}

}
